//
//  HappinessViewController.swift
//  Happiness
//
//  Created by Adela  Yang on 2/16/16.
//  Copyright © 2016 Adela  Yang. All rights reserved.
//

import UIKit

class HappinessViewController: UIViewController, HappinessViewDataSource {
    
    private struct Constants {
        static let HappinessGestureScale: CGFloat = 4
        
    }

    var happiness: Int = 50 { //0 = sad, 100 = joyful
        didSet {
            happiness = min(max(happiness, 0), 100)
            updateUI()
        }
    }
    
    @IBOutlet weak var faceView: HappinessView! {
        didSet {
            faceView.dataSource = self
            faceView.addGestureRecognizer(UIPinchGestureRecognizer(target: faceView, action: "scale:"))
        }
    }
    
    @IBAction func changaHappiness(sender: UIPanGestureRecognizer) {
        switch sender.state {
        case .Ended: fallthrough
        case .Changed:
            let translation = sender.translationInView(faceView)
            let happinessChange = -Int(translation.y / Constants.HappinessGestureScale)
            if happinessChange != 0 {
                happiness += happinessChange
                sender.setTranslation(CGPointZero, inView: faceView)
            }
        default: break
        }
        
    }
    
    func updateUI() {
        faceView.setNeedsDisplay()
    }
    
    func smilinessForHappinessView(sender: HappinessView) -> Double? {
        return Double(happiness - 50) / 50
    }
    
    
}
