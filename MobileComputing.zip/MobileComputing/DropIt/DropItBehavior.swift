//
//  DropItBehavior.swift
//  DropIt
//
//  Created by Adela  Yang on 4/5/16.
//  Copyright © 2016 Adela  Yang. All rights reserved.
//

import UIKit

class DropItBehavior: UIDynamicBehavior {

    let gravity = UIGravityBehavior()
    
    lazy var collider: UICollisionBehavior = {
        let lazyCollider = UICollisionBehavior()
        lazyCollider.translatesReferenceBoundsIntoBoundary = true
        return lazyCollider
    }()
    
    lazy var dropBehavior: UIDynamicItemBehavior = {
        let lazyDropBehavior = UIDynamicItemBehavior()
        lazyDropBehavior.allowsRotation = false
        lazyDropBehavior.elasticity = 0.75
        return lazyDropBehavior
    }()
    
    override init() {
        super.init()
        addChildBehavior(gravity)
        addChildBehavior(collider)
        addChildBehavior(dropBehavior)
    }
    
    func addBarrier(path: UIBezierPath, named name: String) {
        collider.removeBoundaryWithIdentifier(name)
        collider.addBoundaryWithIdentifier(name, forPath: path)
    }
    
    func addDrop(drop: UIView) {
        dynamicAnimator?.referenceView?.addSubview(drop)
        gravity.addItem(drop)
        collider.addItem(drop)
        dropBehavior.addItem(drop)
    }
    
    func removeDrop(drop: UIView) {
        gravity.removeItem(drop)
        collider.removeItem(drop)
        dropBehavior.removeItem(drop)
        drop.removeFromSuperview()
    }
    
}
