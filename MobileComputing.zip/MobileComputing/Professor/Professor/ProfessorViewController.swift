
//
//  ViewController.swift
//  Professor
//
//  Created by Adela  Yang on 2/18/16.
//  Copyright © 2016 Adela  Yang. All rights reserved.
//

import UIKit

class ProfessorViewController: UIViewController {
    
    @IBAction func mumbling(sender: UIButton) {
        performSegueWithIdentifier("mumbling", sender: nil)
        
        
        
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        var destination = segue.destinationViewController
        if let navCon = destination as? UINavigationController {
            destination = navCon.visibleViewController!
        }
        if let hvc = segue.destinationViewController as? HappinessViewController {
            if let identifier = segue.identifier {
                switch identifier {
                case "sad": hvc.happiness = 0
                case "happy": hvc.happiness = 100
                case "mumbling": hvc.happiness = 25
                default: hvc.happiness = 50
                }
            }
        }
    }
    

}

