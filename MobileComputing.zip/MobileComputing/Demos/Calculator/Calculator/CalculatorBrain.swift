//
//  CalculatorBrain.swift
//  Calculator
//
//  Created by Adela  Yang on 2/2/16.
//  Copyright © 2016. All rights reserved.
//


/*  NOTES

    things are usually public but only within this app
    good coding - make it private
    delegate process
    swift is pass by value as opposed to reference
*/

import Foundation

class CalculatorBrain
{
    private var opStack = [Op]()
    
    //basically a dictionary
    private var knownOps = [String:Op]()
    
    var program: AnyObject { // guaranteed to be a PropertyList
        get {
            return opStack.map { $0.description }
        }
        set {
            if let opSymbols = newValue as? Array<String> {
                var newOpStack = [Op]()
                for opSymbol in opSymbols {
                    if let op = knownOps[opSymbol] {
                        newOpStack.append(op)
                    } else if let operand = NSNumberFormatter.numberFromString(opSymbol)?.doubleValue {
                        newOpStack.append(.Operand(operand))
                    }
                }
            }
        }
    }
    
    private enum Op : CustomStringConvertible { // implemented customDebug protocol
        case Operand(Double)
        case UnaryOperation(String, Double -> Double)
        case BinaryOperation(String, (Double, Double) -> Double)
        
        //read only property returns a strin
        var description: String {
            get {
                switch self {
                case .Operand(let operand):
                    return "\(operand)"
                case .UnaryOperation(let symbol, _):
                    return symbol
                case .BinaryOperation(let symbol, _):
                    return symbol
                }
            }
        }
    }
    
    init() {
        func learnOp(op: Op) {
            knownOps[op.description] = op
        }
        learnOp(Op.BinaryOperation("×", *))
//        knownOps["×"] = Op.BinaryOperation("×", *)
        knownOps["-"] = Op.BinaryOperation("-") {$1 - $0}
        knownOps["+"] = Op.BinaryOperation("+", +)
        knownOps["÷"] = Op.BinaryOperation("÷") {$1 / $0}
        knownOps["√"] = Op.UnaryOperation("√", sqrt)
    }

    
    private func evaluate(ops: [Op]) -> (result: Double?, remainingOps:[Op]) { //Tuple
        if !ops.isEmpty { //property not method in swift
            var remainingOps = ops // take things on and off, need a fresh copy
            let op = remainingOps.removeLast()
            switch op {
            case .Operand(let operand): //. is syntax for enumerated types
                return (operand, remainingOps)
            case.UnaryOperation(_, let operation): //_ is don't care
                let operandEvaluation = evaluate(remainingOps)
                if let operand = operandEvaluation.result {
                    return (operation(operand), operandEvaluation.remainingOps)
                }
            case .BinaryOperation(_, let operation):
                let operandEvaluation = evaluate(remainingOps)
                if let operand = operandEvaluation.result {
                    let operandEvaluation2 = evaluate(operandEvaluation.remainingOps)
                    if let operand2 = operandEvaluation2.result {
                        return (operation(operand, operand2), operandEvaluation2.remainingOps)
                    }
                }

            }
        }
        return (nil, ops)
    }
    
    
    // ? is an optional -- ability to handle errors more elegantly

    func evaluate() -> Double? {
        //let (result, _) = evaluate(opStack)
        // print opstack return
        return evaluate(opStack).result
        
    }
    
    func pushOperand(operand: Double) -> Double? {
        opStack.append(Op.Operand(operand))
        print("\(opStack)")
        return evaluate()
    }
    
    func performOperation(symbol: String) -> Double? {
        //set this constant to the op of the symbol i have
        if let operation = knownOps[symbol] {
            opStack.append(operation)
            print("\(opStack)")
            return evaluate()
        }
        
        return nil
        
    }
    
}













