//
//  ViewController.swift
//  Calculator
//
//  Created by Son D. Ngo on 1/28/16.
//  Copyright © 2016 Son D. Ngo. All rights reserved.
//



// for the assignment: x,y,operand
// operator pressed repeatedly: take first two, then add the third operand

/* autolayout notes:
     get within the blue lines
     set the constraints, click the yellow warning label and fix the misplacement
    yellow good, red bad
     get rid of all constraints
    right circle with square inside labels and button
    drag outward on all 4 side and first option --- do this for the big ones
    set the constraints

*/
//swift is  a functional language

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var display: UILabel!

    var userIsTypingANumber = false
    
    var brain = CalculatorBrain()
    
    //array of doubles
//    var operandStack = [Double]()
    
    @IBAction func digitPressed(sender: UIButton) {
        let digit = sender.currentTitle!
        print("digit = \(digit)")
//        if userIsInTheMiddleOfTypingANumber {

        
        if userIsTypingANumber {
            display.text = display.text! + digit
        } else {
            display.text = digit
            userIsTypingANumber = true
        }
    }
    
    @IBAction func enter() {
        userIsTypingANumber = false
        if let result = brain.pushOperand(displayValue) {
            displayValue = result
        } else {
            displayValue = 0
        }
        
        
//        let operand = displayValue
//        operandStack.append(operand)
        //number in display is a string
        
    }
    
    @IBAction func operate(sender:UIButton) {
        if userIsTypingANumber {
            enter()
        }
        // unwrap (!) because it is an optional
        if let operation = sender.currentTitle {
            if let result = brain.performOperation(operation) {
                displayValue = result
            } else {
                displayValue = 0
            }
            
        }
    }
        
        
        
//        switch operation {
//            case "×":// how to grab the multiply?
////                // must grab text from the main storyboard
////                if operandStack.count >= 2 {
////                    displayValue = operandStack.removeLast() *
////                        operandStack.removeLast()
////                    enter()
//                //performOperation(*)
//                performOperation { $0 * $1 }
//
////            }
//            case "÷":
//                performOperation { $1 / $0 }
//            case "+":
//                performOperation { $0 + $1 }
//            case "−":
//                performOperation { $1 - $0 }
//            case "⎷":
//                performSingleOperation { sqrt($0) }
//        default: break
//        }
    //}
    
//    func multiply(op1: Double, op2: Double) -> Double {
//            return op1 * op2
//    }
    
//    func performOperation(operation: (Double, Double) -> Double) {
//        if operandStack.count >= 2 {
//            displayValue = operation(operandStack.removeLast(),
//                operandStack.removeLast())
//            enter()
//        }
//
//    }
//    
//    func performSingleOperation(operation: (Double) -> Double) {
//        if operandStack.count >= 2 {
//            displayValue = operation(operandStack.removeLast())
//            enter()
//        }
//    }
    
    var displayValue: Double {
        get {
            //exclamation unravels it
            //something with a question mark
            return NSNumberFormatter().numberFromString(display.text!)!.doubleValue
        }
        
        set {
            //print it out is \()
            display.text = "\(newValue)"
//            print("operandStack= \(operandStack)")
        }
    }

}

