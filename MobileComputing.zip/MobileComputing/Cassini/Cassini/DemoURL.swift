//
//  DemoURL.swift
//


import Foundation

struct DemoURL {
    static let Bowdoin = NSURL(string: "https://www.bowdoin.edu/government/images/bowdoin-hubbard-hall-spring-2012.jpg")
    struct NASA {
        static let Cassini = NSURL(string: "http://www.jpl.nasa.gov/images/cassini/20090202/pia03883-full.jpg")
        static let Earth = NSURL(string: "http://www.nasa.gov/sites/default/files/wave_earth_mosaic_3.jpg")
        static let Saturn = NSURL(string: "http://www.nasa.gov/sites/default/files/saturn_collage.jpg")
    }
}
